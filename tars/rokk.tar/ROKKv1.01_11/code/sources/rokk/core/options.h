/*
 * options.h
 *
 *  Created on: 2014/03/08
 *      Author: setner
 */

#ifndef OPTIONS_H_
#define OPTIONS_H_

using namespace Minisat;

//=================================================================================================
// Options:


static const char* _cat = "CORE";

static DoubleOption  opt_var_decay             (_cat, "var-decay",   "The variable activity decay factor",            0.95,     DoubleRange(0, false, 1, false));
static DoubleOption  opt_clause_decay          (_cat, "cla-decay",   "The clause activity decay factor",              0.999,    DoubleRange(0, false, 1, false));
static DoubleOption  opt_random_var_freq       (_cat, "rnd-freq",    "The frequency with which the decision heuristic tries to choose a random variable", 0, DoubleRange(0, true, 1, true));
static DoubleOption  opt_random_seed           (_cat, "rnd-seed",    "Used by the random variable selection",         91648253, DoubleRange(0, false, HUGE_VAL, false));
static IntOption     opt_ccmin_mode            (_cat, "ccmin-mode",  "Controls conflict clause minimization (0=none, 1=basic, 2=deep)", 2, IntRange(0, 2));
static IntOption     opt_phase_saving          (_cat, "phase-saving", "Controls the level of phase saving (0=none, 1=limited, 2=full)", 2, IntRange(0, 2));
static BoolOption    opt_rnd_init_act          (_cat, "rnd-init",    "Randomize the initial activity", false);
static BoolOption    opt_luby_restart          (_cat, "luby",        "Use the Luby restart sequence", true);
static IntOption     opt_restart_first         (_cat, "rfirst",      "The base restart interval", 100, IntRange(1, INT32_MAX));
static DoubleOption  opt_restart_inc           (_cat, "rinc",        "Restart interval increase factor", 2, DoubleRange(1, false, HUGE_VAL, false));
static DoubleOption  opt_garbage_frac          (_cat, "gc-frac",     "The fraction of wasted memory allowed before a garbage collection is triggered",  0.20, DoubleRange(0, false, HUGE_VAL, false));

static const char* _sinn = "SINN";

static IntOption     opt_agg_db                (_sinn, "ag", "0 : minisat, 1 : glue, 2 : fixed, 3 : fix + cd/pd+cd/(lcd+pd)", 3, IntRange(0,3));
static IntOption     opt_firm_nlbd             (_sinn, "firm_nlbd", "", 2, IntRange(0, INT32_MAX));
static BoolOption    opt_ture_lbd              (_sinn, "true", "", true);

static const char* _glue = "GLUE";

static IntOption     opt_learnts_init          (_glue, "linit", "", 30000, IntRange(1,INT32_MAX));
static IntOption     opt_learnts_inc           (_glue, "linc", "", 10000, IntRange(1,INT32_MAX));

static const char* _rokk = "ROKK";

static IntOption     opt_reduce_db_method      (_rokk, "rdb", "0 : sinn, 1 : rokk",1, IntRange(0,1));
static IntOption     opt_rdb_2_2               (_rokk, "rdb_2_2", "", 200000, IntRange(0, INT32_MAX));
static IntOption     opt_rdb_2_3               (_rokk, "rdb_2_3", "", 150000, IntRange(0, INT32_MAX));
static IntOption     opt_rdb_2_4               (_rokk, "rdb_2_4", "", 100000, IntRange(0, INT32_MAX));
static IntOption     opt_rdb_3_2               (_rokk, "rdb_3_2", "", 110000, IntRange(0, INT32_MAX));
static IntOption     opt_rdb_3_3               (_rokk, "rdb_3_3", "", 75000,  IntRange(0, INT32_MAX));
static IntOption     opt_rdb_3_4               (_rokk, "rdb_3_4", "", 65000,  IntRange(0, INT32_MAX));
static IntOption     opt_rdb_4_2               (_rokk, "rdb_4_2", "", 75000,  IntRange(0, INT32_MAX));
static IntOption     opt_rdb_4_3               (_rokk, "rdb_4_3", "", 55000,  IntRange(0, INT32_MAX));
static IntOption     opt_rdb_4_7               (_rokk, "rdb_4_7", "", 55000,  IntRange(0, INT32_MAX));
static IntOption     opt_rdb_4_8               (_rokk, "rdb_4_8", "", 30000,  IntRange(0, INT32_MAX));

static IntOption     opt_fix_rdb_base          (_rokk, "fix_rdb_base","", 30000, IntRange(0, INT32_MAX));
static IntOption     opt_fix_rdb_inc           (_rokk, "fix_rdb_inc", "", 10000, IntRange(0, INT32_MAX));
static IntOption     opt_fix_inc_method        (_rokk, "fix_inc_method", "", 0, IntRange(0,1));

static IntOption     opt_cdpd_length           (_rokk, "cdpd_leng", "", 1000, IntRange(0, INT32_MAX));
static DoubleOption  opt_cdpd_rate             (_rokk, "cdpd_rate", "", 1.00, DoubleRange(0, false, INT32_MAX, true));
static IntOption     opt_lcdcdpd_length        (_rokk, "lcdcdpd_leng", "", 1000, IntRange(0, INT32_MAX));
static DoubleOption  opt_lcdcdpd_rate          (_rokk, "lcdcdpd_rate", "", 1.00, DoubleRange(0, false, INT32_MAX, true));
static IntOption     opt_shrink_interval       (_rokk, "shrink_interval", "", 524288, IntRange(0, INT32_MAX));

static const char* _zenn = "ZENN";

static IntOption     opt_phase_shift           (_zenn, "ps", "0 : no, 1 : static, 2 : dynamic", 1, IntRange(0, 2));
static IntOption     opt_sat_phase_length      (_zenn, "s_ph_leng", "", 32, IntRange(0, INT32_MAX));
static IntOption     opt_unsat_phase_length    (_zenn, "u_ph_leng", "", 128, IntRange(0, INT32_MAX));
static IntOption     opt_sat_restart           (_zenn, "s_res", "", 0, IntRange(0, 7));
static IntOption     opt_unsat_restart         (_zenn, "u_res", "", 4, IntRange(0, 7));

static IntOption     opt_lbd_restart_length    (_zenn, "lbd_res_leng", "", 50, IntRange(0, INT32_MAX));
static DoubleOption  opt_lbd_restart_rate      (_zenn, "lbd_res_rate", "", 0.80, DoubleRange(0, false, INT32_MAX, true));
static IntOption     opt_dlv_restart_length    (_zenn, "dlv_res_leng", "", 50, IntRange(0, INT32_MAX));
static DoubleOption  opt_dlv_restart_rate      (_zenn, "dlv_res_rate", "", 1.00, DoubleRange(0, false, INT32_MAX, true));
static IntOption     opt_btlv_restart_length   (_zenn, "btlv_res_leng", "", 50, IntRange(0, INT32_MAX));
static DoubleOption  opt_btlv_restart_rate     (_zenn, "btlv_res_rate", "", 1.05, DoubleRange(0, false, INT32_MAX, true));

#endif /* OPTIONS_H_ */
