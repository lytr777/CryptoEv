#!/bin/sh

cd code

export MROOT=$PWD

make -C simp r
cp simp/minisat_release ../binary/rokk


 
