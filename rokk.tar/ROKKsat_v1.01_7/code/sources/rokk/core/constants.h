/*
 * constants.h
 *
 *  Created on: 2014/03/07
 *      Author: setner
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define MAX_LBD 15
#define MAX_INIT_LBD 7

// reduce method
#define REDUCE_SINN 0
#define REDUCE_ROKK 1

// aggressive_reduce_method
#define AGG_MINISAT 0
#define AGG_GLUE 1
#define AGG_FIX 2
#define AGG_FIX_CDPD_LCDCDPD 3

// fix inc method
#define FIX_CONSTANT 0
#define FIX_LINEAR 1

// restart method
#define RESTART_LUBY 0
#define RESTART_LBD 1
#define RESTART_DLV 2
#define RESTART_BTLV 3
#define RESTART_LBD_DLV 4
#define RESTART_DLV_BTLV 5
#define RESTART_BTLV_LBD 6
#define RESTART_LBD_DLV_BTLV 7

// phase shift
#define PHASE_SHIFT_NO 0
#define PHASE_SHIFT_STATIC 1
#define PHASE_SHIFT_DYNAMIC 2

#define PHASE_SAT 0
#define PHASE_UNSAT 1

#endif /* CONSTANTS_H_ */
