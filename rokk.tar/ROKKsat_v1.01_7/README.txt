For compiling : 
   ./build.sh

For running
cd binary
rokk.sh BENCHNAME TEMPDIR

